MUX TO LP H/W CONNECTIONS

IO23 ---> COM
IO24 --->S0
IO25 --->S1
IO26 --->S2
IO27 --->S3

Passes an array of reading for CHAN0--> CHAN11

Upload hex file or import CCS zip as an archive project. It should compile without errors.


SC driver project is also included in SC folder: 

You can open with Sensor controller Studio.

